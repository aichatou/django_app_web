# django_app_web
Application Web Django pour la gestion de données
